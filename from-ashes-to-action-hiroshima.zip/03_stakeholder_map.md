# Stakeholder Map

### 👥 1. Citizens of Hiroshima
- Survivors needing shelter, medical aid, and long-term care

### 🏛️ 2. Japanese Government & Local Administration
- Responsible for fund allocation, planning, and policy

### 🌐 3. International Community & NGOs
- Humanitarian and logistical support from organizations like the Red Cross

### 🧑‍⚕️ 4. Medical & Scientific Community
- For treatment and radiation research

### 🕊️ 5. Future Generations
- Symbolic stakeholders whose lives will be shaped by what is rebuilt today
